﻿using AppWithAuth.Data;
using AppWithAuth.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AppWithAuth.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {
        private readonly AppDbContext _context;

        public BookController(AppDbContext context)
        {
            _context = context;
        }

        // Admin can delete a book
        [HttpDelete("{id}")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var book = await _context.Books.FindAsync(id);
            if (book == null)
            {
                return NotFound();
            }

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // Manager can add a new book
        [HttpPost]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> AddBook([FromBody] Book book) // Ensure data comes from the body
        {
            if (book == null)
            {
                return BadRequest("Book data is required.");
            }

            // Add the book to the context
            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            // Return a response with the created book
            return CreatedAtAction(nameof(GetBook), new { id = book.Id }, book);
        }

        // Everyone can view books
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Book>>> GetBooks()
        {
            // Retrieve all books from the database
            return await _context.Books.ToListAsync();
        }

        // Get a specific book by ID (optional method)
        [HttpGet("{id}")]
        public async Task<ActionResult<Book>> GetBook(int id)
        {
            var book = await _context.Books.FindAsync(id);

            if (book == null)
            {
                return NotFound();
            }

            return book;
        }
    }
}